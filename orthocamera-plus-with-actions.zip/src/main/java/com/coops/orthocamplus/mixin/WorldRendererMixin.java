package com.coops.orthocamplus.mixin;

import com.coops.orthocamplus.config.OCPlusConfig;
import com.coops.orthocamplus.fade.FadeOccluders;
import com.coops.orthocamplus.util.AlphaTintingVertexConsumer;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/WorldRenderer;renderLayer(Lnet/minecraft/client/render/RenderLayer;Lnet/minecraft/client/util/math/MatrixStack;DDD)V", ordinal = 1))
    private void orthoplus$renderFaded(MatrixStack matrices, float tickDelta, long limitTime, boolean renderBlockOutline, Camera camera, GameRenderer gameRenderer, LightmapTextureManager lightmap, Matrix4f projection, CallbackInfo ci) {
        if (!OCPlusConfig.fadeEnabled) return;
        var client = MinecraftClient.getInstance();
        var world = client.world; if (world == null) return;
        var brm = client.getBlockRenderManager();
        var vbs = client.getBufferBuilders().getEntityVertexConsumers();

        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc();

        int radius = 6;
        BlockPos cam = BlockPos.ofFloored(camera.getPos());
        for (int dx=-radius; dx<=radius; dx++)
            for (int dy=-radius; dy<=radius; dy++)
                for (int dz=-radius; dz<=radius; dz++) {
                    BlockPos p = cam.add(dx,dy,dz);
                    float amt = FadeOccluders.alphaFor(p);
                    if (amt <= 0.02f) continue;
                    var state = world.getBlockState(p);
                    if (state.isAir()) continue;

                    matrices.push();
                    matrices.translate(p.getX()-camera.getPos().x, p.getY()-camera.getPos().y, p.getZ()-camera.getPos().z);
                    VertexConsumer vc = vbs.getBuffer(RenderLayer.getTranslucent());
                    brm.getModelRenderer().render(world, brm.getModel(state), state, p, matrices, new AlphaTintingVertexConsumer(vc, 1f,1f,1f, 1f - OCPlusConfig.fadeStrength*amt), false, world.random, state.getRenderingSeed(p), OverlayTexture.DEFAULT_UV);
                    matrices.pop();
                }
    }
}
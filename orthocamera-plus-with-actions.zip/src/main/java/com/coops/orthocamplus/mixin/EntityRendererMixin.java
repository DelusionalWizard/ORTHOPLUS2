package com.coops.orthocamplus.mixin;

import com.coops.orthocamplus.config.OCPlusConfig;
import com.coops.orthocamplus.util.OcclusionUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin<T extends Entity> {
    @Inject(method = "render", at = @At("RETURN"))
    private void orthoplus$renderReveal(T entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        if (!OCPlusConfig.revealEnabled) return;
        if (OCPlusConfig.revealOnlyWhenOccluded && !OcclusionUtil.isOccluded(MinecraftClient.getInstance(), entity)) return;

        matrices.push();
        try {
            float a = OCPlusConfig.revealAlpha;
            float r = ((OCPlusConfig.revealColor >> 16) & 0xFF) / 255f;
            float g = ((OCPlusConfig.revealColor >> 8) & 0xFF) / 255f;
            float b = (OCPlusConfig.revealColor & 0xFF) / 255f;

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableCull();
            RenderSystem.depthFunc(org.lwjgl.opengl.GL11.GL_ALWAYS);

            VertexConsumerProvider.Immediate immediate = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
            VertexConsumer vc = immediate.getBuffer(RenderLayer.getEntityTranslucent(new Identifier("textures/misc/white.png")));
            var box = entity.getBoundingBox().expand(0.05);
            WorldRenderer.drawBox(matrices, vc, box, r, g, b, a);
            immediate.draw(RenderLayer.getEntityTranslucent(new Identifier("textures/misc/white.png")));

            RenderSystem.depthFunc(org.lwjgl.opengl.GL11.GL_LEQUAL);
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
        } finally {
            matrices.pop();
        }
    }
}
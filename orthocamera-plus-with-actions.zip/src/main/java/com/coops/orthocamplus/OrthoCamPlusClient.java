package com.coops.orthocamplus;

import com.coops.orthocamplus.camera.CameraPresets;
import com.coops.orthocamplus.camera.Smoothers;
import com.coops.orthocamplus.config.OCPlusConfig;
import com.coops.orthocamplus.fade.FadeOccluders;
import com.coops.orthocamplus.fade.FadeSampler;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

public class OrthoCamPlusClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        OCPlusConfig.load();
        Keys.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client == null) return;
            handleKeys(client);
            Smoothers.tick(client);

            if (OCPlusConfig.fadeEnabled) {
                PlayerEntity target = client.player;
                if (target != null) {
                    FadeOccluders.update(client, target.age, FadeSampler.sampleOccluders(client, target));
                }
            }
        });
    }

    private void handleKeys(MinecraftClient mc) {
        while (Keys.TOGGLE_REVEAL.wasPressed()) {
            OCPlusConfig.revealEnabled = !OCPlusConfig.revealEnabled; OCPlusConfig.save();
            toast(mc, "Reveal: " + (OCPlusConfig.revealEnabled?"ON":"OFF"));
        }
        while (Keys.TOGGLE_FADE.wasPressed()) {
            OCPlusConfig.fadeEnabled = !OCPlusConfig.fadeEnabled; OCPlusConfig.save();
            toast(mc, "Occluder Fade: " + (OCPlusConfig.fadeEnabled?"ON":"OFF"));
        }
        while (Keys.PRESET_ISO_NE.wasPressed()) CameraPresets.applyIsometric(mc, 45f);
        while (Keys.PRESET_ISO_NW.wasPressed()) CameraPresets.applyIsometric(mc, 135f);
        while (Keys.PRESET_ISO_SW.wasPressed()) CameraPresets.applyIsometric(mc, 225f);
        while (Keys.PRESET_ISO_SE.wasPressed()) CameraPresets.applyIsometric(mc, 315f);
        while (Keys.SNAP_YAW_0.wasPressed())   CameraPresets.snapYaw(mc, 0f);
        while (Keys.SNAP_YAW_90.wasPressed())  CameraPresets.snapYaw(mc, 90f);
        while (Keys.SNAP_YAW_180.wasPressed()) CameraPresets.snapYaw(mc, 180f);
        while (Keys.SNAP_YAW_270.wasPressed()) CameraPresets.snapYaw(mc, 270f);
        while (Keys.ZOOM_IN.wasPressed())  Smoothers.bumpScale(true);
        while (Keys.ZOOM_OUT.wasPressed()) Smoothers.bumpScale(false);
        while (Keys.TOGGLE_LOCK_ASPECT.wasPressed()) { OCPlusConfig.lockAspect = !OCPlusConfig.lockAspect; OCPlusConfig.save(); }
    }

    private void toast(MinecraftClient mc, String msg) {
        if (mc == null || mc.inGameHud == null) return;
        mc.inGameHud.getChatHud().addMessage(net.minecraft.text.Text.literal("[Ortho+] " + msg));
    }
}
package com.coops.orthocamplus.camera;

import com.coops.orthocamplus.config.OCPlusConfig;
import net.minecraft.client.MinecraftClient;

public final class Smoothers {
    private static float targetScale = 1f;
    private static float currentScale = 1f;

    public static void bumpScale(boolean in) { targetScale *= in ? 1.1f : 0.9f; }

    public static void tick(MinecraftClient mc) {
        currentScale += (targetScale - currentScale) * 0.15f;
        if (OCPlusConfig.lockAspect) {
            // Integrate with OrthoCamera mod scale if exposed.
        } else {
            // Per-axis scale logic placeholder.
        }
    }
}
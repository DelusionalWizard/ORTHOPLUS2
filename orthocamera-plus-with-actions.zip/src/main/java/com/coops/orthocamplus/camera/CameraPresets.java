package com.coops.orthocamplus.camera;

import net.minecraft.client.MinecraftClient;

public final class CameraPresets {
    public static void applyIsometric(MinecraftClient mc, float yawDegrees) {
        if (mc.player == null) return;
        mc.player.setPitch(35.264f);
        mc.player.setYaw(yawDegrees);
    }
    public static void snapYaw(MinecraftClient mc, float yawDegrees) {
        if (mc.player == null) return;
        mc.player.setYaw(yawDegrees);
    }
}
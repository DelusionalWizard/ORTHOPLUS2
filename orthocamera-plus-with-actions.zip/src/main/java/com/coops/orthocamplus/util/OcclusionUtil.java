package com.coops.orthocamplus.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

public final class OcclusionUtil {
    public static boolean isOccluded(MinecraftClient mc, Entity e) {
        if (mc.cameraEntity == null || e == null) return false;
        Vec3d from = mc.gameRenderer.getCamera().getPos();
        Vec3d to   = e.getEyePos();
        HitResult hr = mc.world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.cameraEntity));
        if (hr == null) return false;
        if (hr.getType() == HitResult.Type.BLOCK) {
            double distToTarget = to.distanceTo(((BlockHitResult)hr).getPos());
            return distToTarget > 0.2;
        }
        return false;
    }
}
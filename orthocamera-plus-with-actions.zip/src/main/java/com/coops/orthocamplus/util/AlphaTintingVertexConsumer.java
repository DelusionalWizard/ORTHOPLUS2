package com.coops.orthocamplus.util;

import net.minecraft.client.render.VertexConsumer;

public final class AlphaTintingVertexConsumer implements VertexConsumer {
    private final VertexConsumer parent; private final int rr,gg,bb,aa;
    public AlphaTintingVertexConsumer(VertexConsumer parent, float r, float g, float b, float a){ this.parent=parent; this.rr=(int)(r*255f); this.gg=(int)(g*255f); this.bb=(int)(b*255f); this.aa=(int)(a*255f);}    
    @Override public VertexConsumer color(int r,int g,int b,int a){ return parent.color(rr,gg,bb,aa);}    
    @Override public VertexConsumer vertex(double x,double y,double z){ return parent.vertex(x,y,z);}    
    @Override public VertexConsumer texture(float u,float v){ return parent.texture(u,v);}    
    @Override public VertexConsumer overlay(int u,int v){ return parent.overlay(u,v);}    
    @Override public VertexConsumer light(int u,int v){ return parent.light(u,v);}    
    @Override public VertexConsumer normal(float x,float y,float z){ return parent.normal(x,y,z);}    
    @Override public void next(){ parent.next(); }
    @Override public void fixedColor(int r,int g,int b,int a){ parent.fixedColor(r,g,b,a);}    
    @Override public void unfixColor(){ parent.unfixColor(); }
}
package com.coops.orthocamplus.config;

import com.google.gson.Gson;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

public final class OCPlusConfig {
    private static final Gson GSON = new Gson();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("orthocamera_plus.json");

    public static boolean revealEnabled = true;
    public static float   revealAlpha   = 0.55f;
    public static int     revealColor   = 0x88E0FFFF;
    public static boolean revealOnlyWhenOccluded = true;

    public static boolean fadeEnabled = true;
    public static float   fadeStrength = 0.9f;
    public static int     fadeMaxPositions = 256;
    public static int     fadeRadius = 1;
    public static float   fadeSmoothness = 0.2f;

    public static boolean lockAspect = true;

    public static void load() {
        if (FILE.toFile().exists()) try (Reader r = new InputStreamReader(new FileInputStream(FILE.toFile()), StandardCharsets.UTF_8)) {
            OCPlusConfig o = GSON.fromJson(r, OCPlusConfig.class);
            if (o != null) copyFrom(o);
        } catch (Exception ignored) {}
    }
    public static void save() {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(FILE.toFile()), StandardCharsets.UTF_8)) {
            GSON.toJson(OCPlusConfig.class, OCPlusConfig.class, w);
        } catch (Exception ignored) {}
    }

    private static void copyFrom(OCPlusConfig o) {
        revealEnabled=o.revealEnabled; revealAlpha=o.revealAlpha; revealColor=o.revealColor; revealOnlyWhenOccluded=o.revealOnlyWhenOccluded;
        fadeEnabled=o.fadeEnabled; fadeStrength=o.fadeStrength; fadeMaxPositions=o.fadeMaxPositions; fadeRadius=o.fadeRadius; fadeSmoothness=o.fadeSmoothness;
        lockAspect=o.lockAspect;
    }
}
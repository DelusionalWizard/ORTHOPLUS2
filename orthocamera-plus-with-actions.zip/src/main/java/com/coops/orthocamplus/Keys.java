package com.coops.orthocamplus;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public final class Keys {
    public static KeyBinding TOGGLE_REVEAL, TOGGLE_FADE, TOGGLE_LOCK_ASPECT, ZOOM_IN, ZOOM_OUT;
    public static KeyBinding PRESET_ISO_NE, PRESET_ISO_NW, PRESET_ISO_SW, PRESET_ISO_SE;
    public static KeyBinding SNAP_YAW_0, SNAP_YAW_90, SNAP_YAW_180, SNAP_YAW_270;

    public static void register() {
        String cat = "key.categories.orthocamplus";
        TOGGLE_REVEAL = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.toggleReveal", GLFW.GLFW_KEY_O, cat));
        TOGGLE_FADE   = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.toggleFade",   GLFW.GLFW_KEY_P, cat));
        TOGGLE_LOCK_ASPECT = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.lockAspect", GLFW.GLFW_KEY_L, cat));
        ZOOM_IN  = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.zoomIn",  GLFW.GLFW_KEY_EQUAL, cat));
        ZOOM_OUT = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.zoomOut", GLFW.GLFW_KEY_MINUS, cat));

        PRESET_ISO_NE = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.isoNE", GLFW.GLFW_KEY_KP_1, cat));
        PRESET_ISO_NW = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.isoNW", GLFW.GLFW_KEY_KP_2, cat));
        PRESET_ISO_SW = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.isoSW", GLFW.GLFW_KEY_KP_3, cat));
        PRESET_ISO_SE = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.isoSE", GLFW.GLFW_KEY_KP_4, cat));

        SNAP_YAW_0   = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.snapYaw0",   GLFW.GLFW_KEY_1, cat));
        SNAP_YAW_90  = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.snapYaw90",  GLFW.GLFW_KEY_2, cat));
        SNAP_YAW_180 = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.snapYaw180", GLFW.GLFW_KEY_3, cat));
        SNAP_YAW_270 = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.orthoplus.snapYaw270", GLFW.GLFW_KEY_4, cat));
    }
}
package com.coops.orthocamplus.fade;

import com.coops.orthocamplus.config.OCPlusConfig;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayDeque;
import java.util.Deque;

public final class FadeOccluders {
    public static class Entry { public float alpha = 0f; public float current = 0f; public int lastTick = 0; }

    private static final Long2ObjectOpenHashMap<Entry> fading = new Long2ObjectOpenHashMap<>();
    private static final Deque<Long> lru = new ArrayDeque<>();

    public static void update(MinecraftClient mc, int tick, BlockPos[] hits) {
        fading.values().forEach(e -> e.alpha = 0f);
        for (BlockPos p : hits) {
            long k = p.asLong();
            Entry e = fading.get(k);
            if (e == null) {
                if (fading.size() >= OCPlusConfig.fadeMaxPositions) {
                    Long oldest = lru.pollFirst(); if (oldest != null) fading.remove(oldest);
                }
                e = new Entry(); fading.put(k, e);
            }
            e.alpha = 1f; e.lastTick = tick; lru.remove(k); lru.addLast(k);
        }
        for (Entry e : fading.values()) { e.current = MathHelper.lerp(OCPlusConfig.fadeSmoothness, e.current, e.alpha); }
    }

    public static float alphaFor(BlockPos p) { Entry e = fading.get(p.asLong()); return e==null?0f:e.current; }
}
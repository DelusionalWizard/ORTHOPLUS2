package com.coops.orthocamplus.fade;

import com.coops.orthocamplus.config.OCPlusConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public final class FadeSampler {
    public static BlockPos[] sampleOccluders(MinecraftClient mc, Entity target) {
        Vec3d from = mc.gameRenderer.getCamera().getPos();
        Vec3d to   = target.getEyePos();
        List<BlockPos> out = new ArrayList<>(64);
        int steps = (int)Math.ceil(from.distanceTo(to) * 4.0);
        if (steps < 1) steps = 1;
        Vec3d d = to.subtract(from).multiply(1.0/steps);
        Vec3d p = from;
        for (int i=0;i<steps;i++) {
            p = p.add(d);
            BlockPos bp = BlockPos.ofFloored(p);
            if (mc.world.getBlockState(bp).isOpaque()) {
                int r = OCPlusConfig.fadeRadius;
                for (int dx=-r; dx<=r; dx++)
                    for (int dy=-r; dy<=r; dy++)
                        for (int dz=-r; dz<=r; dz++)
                            out.add(bp.add(dx,dy,dz));
            }
        }
        return out.toArray(BlockPos[]::new);
    }
}